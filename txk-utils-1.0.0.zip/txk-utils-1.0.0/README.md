# Bcc Utils

> A RedM standalone Development API system.

## How to install
* Download this repo
* Copy and paste `bcc-utils` folder to `resources/bcc-utils`
* Add `ensure bcc-utils` to your `server.cfg` file (ABOVE any scripts that use it)
* Now you are ready to get coding!

## API Docs
https://bcc-scripts.com/doc/bcc-utils/